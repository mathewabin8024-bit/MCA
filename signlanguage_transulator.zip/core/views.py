from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_POST
from django.http import JsonResponse
from .forms import SignUpForm, LoginForm
from .models import SpeechTranslation


def home_redirect(request):
    return redirect('core:login')


def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('core:dashboard')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('core:dashboard')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('core:login')


@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html')


@require_POST
@login_required
def save_translation(request):
    # Expect JSON {spoken_text, sign_output, detected_emotion}
    import json
    data = json.loads(request.body.decode('utf-8'))
    spoken = data.get('spoken_text', '')
    sign_output = data.get('sign_output', '')
    emotion = data.get('detected_emotion', '')
    tr = SpeechTranslation.objects.create(
        user=request.user,
        spoken_text=spoken,
        sign_output=sign_output,
        detected_emotion=emotion,
    )
    return JsonResponse({'status': 'ok', 'id': tr.id})
