// Speech to Sign - Demo Logic

// Sign language image library (character-by-character ISL finger-spelling)
// Each letter maps to a sign language image from the Indian folder
const signLibrary = {
  'a': '/static/core/Indian/A/0.jpg',
  'b': '/static/core/Indian/B/0.jpg',
  'c': '/static/core/Indian/C/0.jpg',
  'd': '/static/core/Indian/D/0.jpg',
  'e': '/static/core/Indian/E/0.jpg',
  'f': '/static/core/Indian/F/0.jpg',
  'g': '/static/core/Indian/G/0.jpg',
  'h': '/static/core/Indian/H/0.jpg',
  'i': '/static/core/Indian/I/0.jpg',
  'j': '/static/core/Indian/J/0.jpg',
  'k': '/static/core/Indian/K/0.jpg',
  'l': '/static/core/Indian/L/0.jpg',
  'm': '/static/core/Indian/M/0.jpg',
  'n': '/static/core/Indian/N/0.jpg',
  'o': '/static/core/Indian/O/0.jpg',
  'p': '/static/core/Indian/P/0.jpg',
  'q': '/static/core/Indian/Q/0.jpg',
  'r': '/static/core/Indian/R/0.jpg',
  's': '/static/core/Indian/S/0.jpg',
  't': '/static/core/Indian/T/0.jpg',
  'u': '/static/core/Indian/U/0.jpg',
  'v': '/static/core/Indian/V/0.jpg',
  'w': '/static/core/Indian/W/0.jpg',
  'x': '/static/core/Indian/X/0.jpg',
  'y': '/static/core/Indian/Y/0.jpg',
  'z': '/static/core/Indian/Z/0.jpg',
  ' ': null,  // space between words - no image
  '0': null,  // no image folder for 0
  '1': '/static/core/Indian/1/0.jpg',
  '2': '/static/core/Indian/2/0.jpg',
  '3': '/static/core/Indian/3/0.jpg',
  '4': '/static/core/Indian/4/0.jpg',
  '5': '/static/core/Indian/5/0.jpg',
  '6': '/static/core/Indian/6/0.jpg',
  '7': '/static/core/Indian/7/0.jpg',
  '8': '/static/core/Indian/8/0.jpg',
  '9': '/static/core/Indian/9/0.jpg',
  ',': null,  // punctuation - no image
  '.': null,  // punctuation - no image
  '!': null,  // punctuation - no image
  '?': null,  // punctuation - no image
};

// Emotion detection library (keyword-based)
const emotionKeywords = {
  happy: ['happy', 'joyful', 'excited', 'wonderful', 'great', 'love', 'amazing', 'awesome', '😊'],
  sad: ['sad', 'unhappy', 'miserable', 'depressed', 'down', 'terrible', 'awful', '😢'],
  angry: ['angry', 'furious', 'mad', 'hate', 'rage', 'upset', 'annoyed', '😠'],
  neutral: [],
};

// Initialize microphone on page load
document.addEventListener('DOMContentLoaded', () => {
  const startBtn = document.getElementById('start-rec');
  const emotionBtn = document.getElementById('detect-emotion');

  if (startBtn) {
    startBtn.addEventListener('click', startSpeechRecognition);
  }

  if (emotionBtn) {
    emotionBtn.addEventListener('click', detectEmotion);
  }
});

// Start Speech to Text conversion
function startSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    alert('Speech Recognition not supported in this browser. Use Chrome or Edge.');
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.continuous = false;
  recognition.interimResults = false;

  const startBtn = document.getElementById('start-rec');
  startBtn.disabled = true;
  startBtn.textContent = '🎙️ Listening...';

  recognition.onstart = () => {
    console.log('Speech recognition started');
  };

  recognition.onresult = (event) => {
    let spokenText = '';
    for (let i = event.resultIndex; i < event.results.length; i++) {
      spokenText += event.results[i][0].transcript;
    }
    spokenText = spokenText.toLowerCase().trim();
    console.log('Spoken text:', spokenText);

    // Display recognized text
    const textBox = document.getElementById('recognized-text');
    textBox.textContent = `Recognized: "${spokenText}"`;

    // Convert to sign language
    const signs = convertToSigns(spokenText);
    displaySigns(signs);

    startBtn.disabled = false;
    startBtn.textContent = '🎙️ Start Speech to Sign';
  };

  recognition.onerror = (event) => {
    console.error('Speech Recognition error:', event.error);
    alert('Error: ' + event.error);
    startBtn.disabled = false;
    startBtn.textContent = '🎙️ Start Speech to Sign';
  };

  recognition.start();
}

// Convert text to sign language (character-by-character)
function convertToSigns(text) {
  const chars = text.split('');
  const signs = [];

  chars.forEach((char) => {
    const lowerChar = char.toLowerCase();
    // Get sign image path for character, or null if not found
    const imagePath = signLibrary[lowerChar] !== undefined ? signLibrary[lowerChar] : null;
    signs.push({
      char: char === ' ' ? '[space]' : char,
      imagePath: imagePath,
    });
  });

  return signs;
}

// Display signs (character-by-character) as images - one at a time with 2 second delay
function displaySigns(signs) {
  const signOutput = document.getElementById('sign-output');
  signOutput.innerHTML = '';

  let index = 0;

  function showNextSign() {
    if (index >= signs.length) {
      // All signs displayed, clear the output
      signOutput.innerHTML = '';
      return;
    }

    const { char, imagePath } = signs[index];
    signOutput.innerHTML = '';

    const item = document.createElement('div');
    item.className = 'sign-item';
    
    if (imagePath) {
      // Display image if available
      item.innerHTML = `<img src="${imagePath}" alt="${char}" class="sign-image"><span class="label">${char}</span>`;
    } else {
      // Display label only for spaces and punctuation
      item.innerHTML = `<span class="label">${char}</span>`;
    }
    
    signOutput.appendChild(item);
    index++;

    // Show next sign after 2 seconds
    setTimeout(showNextSign, 2000);
  }

  // Start showing signs
  showNextSign();
}

// Detect emotion (demo rule-based)
function detectEmotion() {
  const textBox = document.getElementById('recognized-text');
  const spokenText = textBox.textContent.toLowerCase();

  let detectedEmotion = 'neutral';
  let emoji = '😐';

  for (const [emotion, keywords] of Object.entries(emotionKeywords)) {
    for (const keyword of keywords) {
      if (spokenText.includes(keyword)) {
        detectedEmotion = emotion;
        break;
      }
    }
    if (detectedEmotion !== 'neutral') break;
  }

  // Set emoji based on emotion
  const emojiMap = {
    happy: '😊',
    sad: '😢',
    angry: '😠',
    neutral: '😐',
  };
  emoji = emojiMap[detectedEmotion] || '😐';

  // Display emotion result
  const emotionLabel = document.getElementById('emotion-label');
  const emotionEmoji = document.getElementById('emotion-emoji');
  emotionLabel.textContent = detectedEmotion.toUpperCase();
  emotionEmoji.textContent = emoji;

  // Save to DB
  saveTranslation(spokenText.split('Recognized: "')[1]?.slice(0, -1) || spokenText, detectedEmotion);
}

// Save translation to database
function saveTranslation(spokenText, emotion) {
  const signs = document.getElementById('sign-output').textContent;

  fetch('/api/save_translation/', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRFToken': getCookie('csrftoken'),
    },
    body: JSON.stringify({
      spoken_text: spokenText,
      sign_output: signs,
      detected_emotion: emotion,
    }),
  })
    .then((response) => response.json())
    .then((data) => console.log('Saved:', data))
    .catch((error) => console.error('Error:', error));
}

// Utility: Get CSRF token
function getCookie(name) {
  let cookieValue = null;
  if (document.cookie && document.cookie !== '') {
    const cookies = document.cookie.split(';');
    for (let i = 0; i < cookies.length; i++) {
      const cookie = cookies[i].trim();
      if (cookie.substring(0, name.length + 1) === name + '=') {
        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
        break;
      }
    }
  }
  return cookieValue;
}
