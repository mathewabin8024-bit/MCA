from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    # Extends default user with phone number
    phone_number = models.CharField(max_length=20, blank=True)


class SpeechTranslation(models.Model):
    user = models.ForeignKey('core.User', on_delete=models.CASCADE)
    spoken_text = models.TextField()
    sign_output = models.TextField(blank=True)  # comma separated sign keys
    detected_emotion = models.CharField(max_length=32, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.spoken_text[:30]}"
