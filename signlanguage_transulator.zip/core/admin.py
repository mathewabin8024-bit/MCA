from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, SpeechTranslation


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ("Extra", {"fields": ("phone_number",)}),
    )


@admin.register(SpeechTranslation)
class SpeechTranslationAdmin(admin.ModelAdmin):
    list_display = ("user", "spoken_text", "detected_emotion", "created_at")
    readonly_fields = ("created_at",)
