# Speech to Sign Language Conversion with Emotion Recognition

A Django-based web application prototype for converting spoken text to sign language with emotion detection.

## 📋 Features

- **User Authentication**: Secure login/signup with email and phone number
- **Speech-to-Text**: Real-time speech recognition using Web Speech API
- **Sign Language Conversion**: Map recognized words to sign language emojis
- **Emotion Detection**: Rule-based emotion detection (Happy, Sad, Angry, Neutral)
- **Database Storage**: All translations and emotions logged to SQLite
- **Responsive UI**: Clean, modern interface with gradient backgrounds

## 🛠️ Tech Stack

- **Backend**: Django 6.0.2
- **Frontend**: HTML5, CSS3, JavaScript
- **Database**: SQLite3
- **APIs**: Web Speech API (browser-native)
- **Emotion Detection**: Keyword-based logic

## 📦 Installation & Setup

### 1. Clone or navigate to the project
```bash
cd c:\sign_projecct\sign
```

### 2. Create a virtual environment
```bash
python -m venv venv
```

### 3. Activate the virtual environment
**Windows:**
```bash
venv\Scripts\activate
```
**macOS/Linux:**
```bash
source venv/bin/activate
```

### 4. Install dependencies
```bash
pip install -r requirements.txt
```

### 5. Create migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create a superuser (for admin panel)
```bash
python manage.py createsuperuser
```

### 7. Run the development server
```bash
python manage.py runserver
```

Server will start at `http://127.0.0.1:8000`

## 🚀 Quick Start

1. **Sign Up** or **Log In**
   - Visit http://127.0.0.1:8000/signup/ to create an account
   - Or log in at http://127.0.0.1:8000/login/

2. **Dashboard**
   - After login, you'll see the dashboard at http://127.0.0.1:8000/dashboard/
   - Click **🎙️ Start Speech to Sign** and allow microphone access
   - Speak a sentence (e.g., "Hello, I am happy")

3. **Speech Detection**
   - The app will convert your speech to text
   - Common words will map to sign language emoji representations

4. **Emotion Recognition**
   - Click **😊 Detect Emotion** to analyze the spoken text
   - The app detects: Happy, Sad, Angry, or Neutral
   - Result is saved to the database

5. **View History** (Admin)
   - Visit http://127.0.0.1:8000/admin/ with your superuser credentials
   - View all speech translations and emotions in the `SpeechTranslation` table

## 📂 Project Structure

```
sign/
├── manage.py                  # Django CLI
├── db.sqlite3                 # Database (auto-created)
├── sign/                      # Main Django config
│   ├── settings.py           # App configuration (includes 'core')
│   ├── urls.py               # URL routing
│   ├── wsgi.py               # WSGI config
│   ├── asgi.py               # ASGI config
│   └── __init__.py
├── core/                      # Main app
│   ├── models.py             # Custom User & SpeechTranslation
│   ├── views.py              # Auth & dashboard views
│   ├── forms.py              # SignUp & Login forms
│   ├── urls.py               # Core app routes
│   ├── admin.py              # Admin configuration
│   ├── apps.py               # App config
│   └── __init__.py
├── templates/                # HTML templates
│   ├── base.html             # Base template with navigation
│   ├── login.html            # Login form
│   ├── signup.html           # Signup form
│   └── dashboard.html        # Main dashboard
├── static/                   # Static assets
│   └── core/
│       ├── css/
│       │   └── style.css     # Global styles
│       └── js/
│           └── main.js       # Speech & emotion logic
└── README.md                 # This file
```

## 🔑 Key Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Redirect to login |
| `/login/` | GET, POST | User login |
| `/signup/` | GET, POST | User registration |
| `/dashboard/` | GET | Main app (requires login) |
| `/logout/` | GET | Logout |
| `/api/save_translation/` | POST | Save speech translation & emotion |
| `/admin/` | GET | Django admin panel |

## 🧠 Emotion Detection Logic

The app uses **keyword-based detection**:

- **Happy**: Keywords like "happy", "joyful", "excited", "amazing"
- **Sad**: Keywords like "sad", "unhappy", "miserable", "down"
- **Angry**: Keywords like "angry", "furious", "mad", "hate"
- **Neutral**: Default when no emotional keywords detected

Demo keywords are hardcoded in `static/core/js/main.js` → `emotionKeywords` object.

## 🗣️ Speech-to-Sign Mapping

The app uses a demo **sign library** with emoji representations:

```javascript
const signLibrary = {
  hello: '👋',
  goodbye: '👋',
  happy: '😊',
  sad: '😢',
  love: '❤️',
  // ... more mappings
};
```

Words are matched via exact match or prefix search. Unmatched words show "❓".

## 🔒 Security Features

- ✅ Django user authentication system
- ✅ CSRF protection on forms
- ✅ Login required decorator on dashboard
- ✅ Secure password hashing (Django default)
- ✅ Session-based user tracking

## 🐛 Troubleshooting

### Speech Recognition not working
- Use **Chrome**, **Edge**, or **Brave** browser
- Check browser permissions for microphone access
- Ensure your microphone is connected and working

### Import errors after running migrations
- Run `python manage.py makemigrations core`
- Then `python manage.py migrate`

### Static files not loading
- Run `python manage.py collectstatic --noinput`

### Database needs reset
- Delete `db.sqlite3`
- Run `python manage.py migrate` again

## 📝 Notes & Future Enhancements

- **Demo-level emotion detection**: Current logic is rule-based. Real ML models (BERT, sentiment analysis) could improve accuracy.
- **Sign library**: Currently uses emoji. Real sign language video clips could enhance UX.
- **API integration**: Could integrate TensorFlow.js for on-device speech recognition.
- **Multi-language**: Could support multiple sign languages (ASL, BSL, ISL).
- **Video recording**: Could save user videos alongside text/emotion data.

## 📜 License

Prototype project for educational purposes.

---

**Enjoy your Speech-to-Sign demo! 🎉**
